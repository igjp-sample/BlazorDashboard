self.assetsManifest = {
  "version": "FHANTHE5",
  "assets": [
    {
      "hash": "sha256-F/ouL9NDtdMLT4ifCHB7IDe5YVhbNX2Om83qa0zl2eE=",
      "url": "BlazorDashboard.styles.css"
    },
    {
      "hash": "sha256-SQeFhFnVpT2uACzvzrbGiIsN/eqUSz4v2jsNeSGjJ44=",
      "url": "Components/ChartView.razor.js"
    },
    {
      "hash": "sha256-6yP+eFYGcE9Fj0tMJ76WIdx0/GyeAjKlSAoVPVhjMN8=",
      "url": "Components/DashboardMenu.razor.js"
    },
    {
      "hash": "sha256-Gxn4g2ppJPbouzDVbAavkUThqHPupr5EjKFTbbItDCY=",
      "url": "Components/GridView.razor.js"
    },
    {
      "hash": "sha256-a/Guici+bHA8ZEk7xC7zupU8tPrYkVP4MsJZwNaM07o=",
      "url": "_content/IgniteUI.Blazor.Documents.Excel/excel.js"
    },
    {
      "hash": "sha256-XFH7+5XpNd66TTd7IED8tXBBjLyZpehZoiOX6lGMwac=",
      "url": "_content/IgniteUI.Blazor/24.418cd3e07b2119ac116e.bundle.js"
    },
    {
      "hash": "sha256-vAUCDKOyKi9XxbA3jL9CA+/8HOR0Abo6PPSrh+9OyC8=",
      "url": "_content/IgniteUI.Blazor/24.418cd3e07b2119ac116e.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-P9sc32i0xiZrTkNaNSwuJuCouFqIALIa90YwBTOzxfI=",
      "url": "_content/IgniteUI.Blazor/24.418cd3e07b2119ac116e.bundle.js.map"
    },
    {
      "hash": "sha256-IOCcUpvSAd6YXYML3vEaOC96CFAmYwcrE4nVNO0jbx4=",
      "url": "_content/IgniteUI.Blazor/309.facf7d11d0b5a5d9d591.bundle.js"
    },
    {
      "hash": "sha256-J5YIjyyUUoqcZV3DP/EKlRp0O/4yeRvK5YNGPzbHspE=",
      "url": "_content/IgniteUI.Blazor/309.facf7d11d0b5a5d9d591.bundle.js.map"
    },
    {
      "hash": "sha256-9O4nDnU3tyZOCoZ42gG59TcUJAv7ocVdXZBNy5Sc9p4=",
      "url": "_content/IgniteUI.Blazor/436.5653d3202852ad867cc1.bundle.js"
    },
    {
      "hash": "sha256-qCTZn2YId3CbK7ofQ714mHq5CsaN5v3w5EyqnlIqvWU=",
      "url": "_content/IgniteUI.Blazor/436.5653d3202852ad867cc1.bundle.js.map"
    },
    {
      "hash": "sha256-RJ72tQwUDiHCdGsuWymoa3IE5NCgSZOJ4h6Zlgu3BR4=",
      "url": "_content/IgniteUI.Blazor/612.bacfc8305036469f2391.bundle.js"
    },
    {
      "hash": "sha256-wdILYNIZazWNk7KoD5alH3EfSfQSUsgfWnNVv8XjB3M=",
      "url": "_content/IgniteUI.Blazor/612.bacfc8305036469f2391.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-+OOf15xol/uRmDEmBXzLwSFBajUB7IdFEJxmWWSoBE4=",
      "url": "_content/IgniteUI.Blazor/612.bacfc8305036469f2391.bundle.js.map"
    },
    {
      "hash": "sha256-t++ALjCnYuHqWGWwYotjWMJyjxZ0wbMHWfa9hsKtV3w=",
      "url": "_content/IgniteUI.Blazor/702.57f0773a47b64605f700.bundle.js"
    },
    {
      "hash": "sha256-vAUCDKOyKi9XxbA3jL9CA+/8HOR0Abo6PPSrh+9OyC8=",
      "url": "_content/IgniteUI.Blazor/702.57f0773a47b64605f700.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-+HvU0PMoT6v7sTwsQXuh8O78shM+fD0a394rtugo8as=",
      "url": "_content/IgniteUI.Blazor/702.57f0773a47b64605f700.bundle.js.map"
    },
    {
      "hash": "sha256-FHTamvU/UANs1gyQrk83naTLTP6GZRm2UBiCh3fV3qI=",
      "url": "_content/IgniteUI.Blazor/793.00e41a95350acc39f172.bundle.js"
    },
    {
      "hash": "sha256-vU9CJ3zaRTedcVklxUKVrSa/4C0Mpu4VsDdjoWNQnrc=",
      "url": "_content/IgniteUI.Blazor/793.00e41a95350acc39f172.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-/vxtOMRerWWkj8p8KNEv2HOOtAaMn/DIdDLzp1zdZeQ=",
      "url": "_content/IgniteUI.Blazor/793.00e41a95350acc39f172.bundle.js.map"
    },
    {
      "hash": "sha256-49O5+6qaQPG8IVspF7YXxch03yjzr2EDiTFFxnxa4mc=",
      "url": "_content/IgniteUI.Blazor/IgniteUI.Blazor.5ypv7keehr.lib.module.js"
    },
    {
      "hash": "sha256-49O5+6qaQPG8IVspF7YXxch03yjzr2EDiTFFxnxa4mc=",
      "url": "_content/IgniteUI.Blazor/IgniteUI.Blazor.Trial.5ypv7keehr.lib.module.js"
    },
    {
      "hash": "sha256-49O5+6qaQPG8IVspF7YXxch03yjzr2EDiTFFxnxa4mc=",
      "url": "_content/IgniteUI.Blazor/IgniteUI.BlazorDebug.5ypv7keehr.lib.module.js"
    },
    {
      "hash": "sha256-Ru/8ADJPVvMqSRy/XfcAcAmhdGaneQqOahzPqY5VhJw=",
      "url": "_content/IgniteUI.Blazor/app.89d45109d29e9d330f29.bundle.js"
    },
    {
      "hash": "sha256-cVNiiL7ZdKNlZWbsiO3U2e04NrH36RnRKNmdDBbIf6Q=",
      "url": "_content/IgniteUI.Blazor/app.89d45109d29e9d330f29.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-KMuB0Cx5SKGieHAi3CIfhbrQA83pE1qHC5ANxatNLyY=",
      "url": "_content/IgniteUI.Blazor/app.89d45109d29e9d330f29.bundle.js.map"
    },
    {
      "hash": "sha256-nJq4oZ043Pngj8NT5MEwCkdPv2LKIBn1pO3DTEsPnYU=",
      "url": "_content/IgniteUI.Blazor/app.bootstrap.js"
    },
    {
      "hash": "sha256-kU7+qxp7WHkASnjw5qpyfYTkcX7g+cPmnG0wbCiN0ig=",
      "url": "_content/IgniteUI.Blazor/app.bundle.js"
    },
    {
      "hash": "sha256-CUTSqt5lZ8zZKKTm328ss5FZp7FZ2Wuo4V+bKx+rmrU=",
      "url": "_content/IgniteUI.Blazor/heatWorker.js"
    },
    {
      "hash": "sha256-fvUTnQoRpuL8jwMX17SwOeOtFtwqeElFn4Sfd2U3atE=",
      "url": "_content/IgniteUI.Blazor/heatWorker.js.LICENSE.txt"
    },
    {
      "hash": "sha256-Pfy+1Wb0/EMUtwZuyf9R94aMqoDZ+IjZslw+VQD2GjA=",
      "url": "_content/IgniteUI.Blazor/heatWorker.js.map"
    },
    {
      "hash": "sha256-oYuDQ925RWu3pfsjavGZlFBR4XJZrwHUmsZNfwA9L5M=",
      "url": "_content/IgniteUI.Blazor/igniteui-angular-elements.584487d3ae4590e75c4b.bundle.js"
    },
    {
      "hash": "sha256-Tnpvp4glaYMbeMd+UFv/1evPsCoYBo5gpn9gAFkXl5U=",
      "url": "_content/IgniteUI.Blazor/igniteui-angular-elements.584487d3ae4590e75c4b.bundle.js.map"
    },
    {
      "hash": "sha256-DD/9fwI6t8DUcZJnmOhk0PCUexROSOa+Yto1tuMgnX4=",
      "url": "_content/IgniteUI.Blazor/igniteui-dockmanager.f7c0a1980c7147170373.bundle.js"
    },
    {
      "hash": "sha256-mhNcbEnByEJxJzOXT7oCQlJIWr7Kjp13x8xRs9KQeEA=",
      "url": "_content/IgniteUI.Blazor/igniteui-dockmanager.f7c0a1980c7147170373.bundle.js.LICENSE.txt"
    },
    {
      "hash": "sha256-Bu8Mhpehi2om45mshbnZUl+1XIF2yQy/nrHkcJJlUNg=",
      "url": "_content/IgniteUI.Blazor/igniteui-dockmanager.f7c0a1980c7147170373.bundle.js.map"
    },
    {
      "hash": "sha256-KHdR4Z6PEAdtYk4mehCsPE854Y9zrq0HwiuXASQiu6M=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-charts.02c26fe1b7abbf7a8f0c.bundle.js"
    },
    {
      "hash": "sha256-GJCf27wdL56PA+ltv8vNoY8xvam5knX6ESZvrBJPq5A=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-charts.02c26fe1b7abbf7a8f0c.bundle.js.map"
    },
    {
      "hash": "sha256-8bEP2Wn/oX1/jXoafAbNZlcc/J+F1BmUuj2L18FLn5I=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-core.5b4c76e45dee2e9057e1.bundle.js"
    },
    {
      "hash": "sha256-3TXFy0JbcOjgXuk5NMzqvSu4lC8gHJyc/5EFg6XJ4ik=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-core.5b4c76e45dee2e9057e1.bundle.js.map"
    },
    {
      "hash": "sha256-Yqd2EiHWG4fkuvSm6BVRSDsK+9didBlOSf/DvWchm9s=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-dashboards.25b8f4269c7fef8ac479.bundle.js"
    },
    {
      "hash": "sha256-7IX9FIq7DcgCRwxmMU1rRwD+u7TdoSzCeLnZTX4wVRA=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-dashboards.25b8f4269c7fef8ac479.bundle.js.map"
    },
    {
      "hash": "sha256-QZ01FEW2hJKnauP4PyJIwNligO9lBZbkApNaMxVS/Go=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-data-grids.4ca1993c141395b79970.bundle.js"
    },
    {
      "hash": "sha256-+f96LVtdgO+R9f7GyJNBd7K14VTIKXxwRMiZeBhXDIo=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-data-grids.4ca1993c141395b79970.bundle.js.map"
    },
    {
      "hash": "sha256-BtxnX3wZGidiIePE8Am60TDk11ER6Jli09FN6XJPFWU=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-gauges.0de661c51d81b188e485.bundle.js"
    },
    {
      "hash": "sha256-oCQq1gzUvbeA5Zp6AWzQKLDK9STd0FK+Wq7asHkvUQk=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-gauges.0de661c51d81b188e485.bundle.js.map"
    },
    {
      "hash": "sha256-au8ybXV/BEZFaCVkzTVMyxFG9dGIsU/mvRZ/VSos3Us=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-inputs.22c83d19662cd0cdbeaa.bundle.js"
    },
    {
      "hash": "sha256-KzEnk9zqfUuddJk4CDPdWvWQRBaDVpTLnlx+WWMeT5I=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-inputs.22c83d19662cd0cdbeaa.bundle.js.map"
    },
    {
      "hash": "sha256-MqBw/XekHY5z95xeSmYDusdvmDqHNpqspHnT8AL/GxE=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-layouts.3d4f8c4236f49ccdf638.bundle.js"
    },
    {
      "hash": "sha256-OmcRUOT/oc41fmVseJItMIctv7rGhY9st58h7uxdmLQ=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-layouts.3d4f8c4236f49ccdf638.bundle.js.map"
    },
    {
      "hash": "sha256-EW9nJ4C0Crz91xsR44AyvsGGP9n6h5z/Mct4AV6zyoM=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-maps.8c29e214f77dfc33e8f6.bundle.js"
    },
    {
      "hash": "sha256-wR2BJNDrWpBoHP5xqUA0eW37rFCcRWDxgd/PqIaFz04=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents-maps.8c29e214f77dfc33e8f6.bundle.js.map"
    },
    {
      "hash": "sha256-u/rXIp2+YE4+OAdNYDPKzhoulWyzwwcV0zq4GjZG9Cw=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents.2af3faa6a05281cd2277.bundle.js"
    },
    {
      "hash": "sha256-B4Y69SRyDDPdo/vsZYHnjzmtx2Ahy2sBoNm+rMjIBAw=",
      "url": "_content/IgniteUI.Blazor/igniteui-webcomponents.2af3faa6a05281cd2277.bundle.js.map"
    },
    {
      "hash": "sha256-DCuTl8pPdaDGycrAP/QLJ+gUBAIrrx4yRtd8ReNOMeA=",
      "url": "_content/IgniteUI.Blazor/igniteui-webgrids.7601a45d0f180ab0421b.bundle.js"
    },
    {
      "hash": "sha256-hOIFOBSUOftCMHfNfkzKlpvkGFrOjBMSq3VByX2Or9Q=",
      "url": "_content/IgniteUI.Blazor/igniteui-webgrids.7601a45d0f180ab0421b.bundle.js.map"
    },
    {
      "hash": "sha256-FOP9GVMwgMabQO3GnR5um82VvcyXzyWSh3UqZjGOdsM=",
      "url": "_content/IgniteUI.Blazor/igniteui-webinputs.dab5c4c5ccdd6864d184.bundle.js"
    },
    {
      "hash": "sha256-vxYW9Y6tyOJcLeTUmqd1oi4Pv1cyPHXbJj/56iP8q+s=",
      "url": "_content/IgniteUI.Blazor/igniteui-webinputs.dab5c4c5ccdd6864d184.bundle.js.map"
    },
    {
      "hash": "sha256-ZMZgoLctX9TzA6SvgfBPJS53Xbi/g3+3GP4whZmCcJc=",
      "url": "_content/IgniteUI.Blazor/themes/dark/bootstrap.css"
    },
    {
      "hash": "sha256-YzZaoAHF8mEII9SuKIakkJgA8lN+XEqP4Kny/zEX7wg=",
      "url": "_content/IgniteUI.Blazor/themes/dark/fluent.css"
    },
    {
      "hash": "sha256-z5CsuALJQMFBJApT4Z61cNv6inTIZgc2Q3Oeb81+MHs=",
      "url": "_content/IgniteUI.Blazor/themes/dark/indigo.css"
    },
    {
      "hash": "sha256-kg9pkEYPqBDsAZJvNgmX5Hk7h8RqVlgRfoie8GyfyAU=",
      "url": "_content/IgniteUI.Blazor/themes/dark/material.css"
    },
    {
      "hash": "sha256-AbpHGcgLb+kRsJGnwFEktk7uzpZOCcBY74+YBdrKVGs=",
      "url": "_content/IgniteUI.Blazor/themes/grid/_util.css"
    },
    {
      "hash": "sha256-AbpHGcgLb+kRsJGnwFEktk7uzpZOCcBY74+YBdrKVGs=",
      "url": "_content/IgniteUI.Blazor/themes/grid/_variables.css"
    },
    {
      "hash": "sha256-QGfTE2BlDSAARIhxa6WPmTg6rwPWLzo0DDTqaDV/ZIs=",
      "url": "_content/IgniteUI.Blazor/themes/grid/dark/bootstrap.css"
    },
    {
      "hash": "sha256-eqiRf/aKeVK/axn8on4cTPO92Cgp/4q5+XCrCzPYOvw=",
      "url": "_content/IgniteUI.Blazor/themes/grid/dark/fluent.css"
    },
    {
      "hash": "sha256-YDVpkzXHi7XQpoF566gu5zohqFN5AO5wikX59HFyYxE=",
      "url": "_content/IgniteUI.Blazor/themes/grid/dark/indigo.css"
    },
    {
      "hash": "sha256-V2su6RFUNKTe7PtYlwt8cwy/fJE40+VQjfPy9HI8A3g=",
      "url": "_content/IgniteUI.Blazor/themes/grid/dark/material.css"
    },
    {
      "hash": "sha256-GR29h7tKOOxA8Mg4rJbjEJgagdcj37wCbF3E8o/+edw=",
      "url": "_content/IgniteUI.Blazor/themes/grid/light/bootstrap.css"
    },
    {
      "hash": "sha256-jJSENyuO/muzzzWX/Y9K4A3XPOYJke9X1oXFsT9E274=",
      "url": "_content/IgniteUI.Blazor/themes/grid/light/fluent.css"
    },
    {
      "hash": "sha256-BSHzO5DcU8SX65aKHIu+jgYLzoh/0MCQxSmu5oiIHcI=",
      "url": "_content/IgniteUI.Blazor/themes/grid/light/indigo.css"
    },
    {
      "hash": "sha256-1gr26GzcichUrj3tHYPjXsDS/3f8OZVluUuTx5Wdx0I=",
      "url": "_content/IgniteUI.Blazor/themes/grid/light/material.css"
    },
    {
      "hash": "sha256-q0vUK31Ufej1XIE63Gvk9QD7vaQKa9jEwG78IevlSLw=",
      "url": "_content/IgniteUI.Blazor/themes/light/bootstrap.css"
    },
    {
      "hash": "sha256-ZR9MvllUkymuoZ8zlgxucIsYZcwPtf/G8yHSwlJEXxg=",
      "url": "_content/IgniteUI.Blazor/themes/light/fluent.css"
    },
    {
      "hash": "sha256-UTLb8qgG75Z5hW4/LAO4tsX+T7S2lQtQH5lggsKS8ho=",
      "url": "_content/IgniteUI.Blazor/themes/light/indigo.css"
    },
    {
      "hash": "sha256-NvwtzPudLyDERwFJPZZv4XFdNQ2L/uv2nj6RRgi+EYM=",
      "url": "_content/IgniteUI.Blazor/themes/light/material.css"
    },
    {
      "hash": "sha256-yEpb3vXc7l7/qmiEWUNfWHN9EnLRY7PddqDP9utPlpg=",
      "url": "_content/Toolbelt.Blazor.FileDropZone/script.min.js"
    },
    {
      "hash": "sha256-XiJCLB0yiveDAkAYzdyBGuYApU6cpdHUQzIZnLpAMhw=",
      "url": "_content/Toolbelt.Blazor.I18nText/Toolbelt.Blazor.I18nText.e95ckhss32.lib.module.js"
    },
    {
      "hash": "sha256-3noI3A9OZSB3leNQ5mJnVnUWInCHauhs7pmB4my48FE=",
      "url": "_content/Toolbelt.Blazor.I18nText/helper.min.js"
    },
    {
      "hash": "sha256-2yb6uF9df0DV2ufJGR+b6esqkQF/c+ejI9Vmacz+eK4=",
      "url": "_content/i18ntext/BlazorDashboard.I18nText.LocalizedText.en.json"
    },
    {
      "hash": "sha256-UCnUPPycxrll2xGPno6JGc24NXZk1r7apyANqhRsJOw=",
      "url": "_content/i18ntext/BlazorDashboard.I18nText.LocalizedText.ja.json"
    },
    {
      "hash": "sha256-MBltyKSz16waWDxkapwdFawPCIYxzDzSnssGv12O4GM=",
      "url": "_content/i18ntext/BlazorDashboard.I18nText.LocalizedText.ko.json"
    },
    {
      "hash": "sha256-ULnE1PBacs/smitUX4QZV3krGBGTgBY99srnG+ml2lI=",
      "url": "_framework/BlazorDashboard.sd0fbrmshb.wasm"
    },
    {
      "hash": "sha256-JjPQKPqAsOmAwhej5KVX/fJlYwM4jk3DX+1ft/IsblA=",
      "url": "_framework/HarfBuzzSharp.6tk6ybnp47.wasm"
    },
    {
      "hash": "sha256-5TFK5QqP8WEOY5YbYnutQb4C8iG+yY/H8hcPUEC7L2U=",
      "url": "_framework/IgniteUI.Blazor.Documents.Core.xtn5ev0i5s.wasm"
    },
    {
      "hash": "sha256-/zVGIjQMCAc1OEkGaWBTas/J0SEksidYByohgriTkY4=",
      "url": "_framework/IgniteUI.Blazor.Documents.Excel.72b4dqdid8.wasm"
    },
    {
      "hash": "sha256-ctXyg6LLBoiJF82jM2jnAm95z9sph6BVwKMOkxnDqkk=",
      "url": "_framework/IgniteUI.Blazor.m2z44v0phh.wasm"
    },
    {
      "hash": "sha256-TbW2oirSRZ0v8PO5iLSgSh9pa5IwSQ4zVs37dOuVrdI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.56vm27zilx.wasm"
    },
    {
      "hash": "sha256-EAzCZQvTFLlS01met9Sagc/rkiGjEupkKXQDZdweF9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.4vju0fnx0n.wasm"
    },
    {
      "hash": "sha256-O/d3/8UUKgaUIgHu6wzm4VDnNYJI2lJ8NtgQ+KNHKLY=",
      "url": "_framework/Microsoft.AspNetCore.Components.lcwcuvauel.wasm"
    },
    {
      "hash": "sha256-3DH5Li3nbKgskNzRybjZBIfXSoxH/TN0wolg2KHl/YQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.w7skqr0zek.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-FU9TpGEmQwWgADUtlXFTdJIwsCDEyFtgEJacSi8iIoY=",
      "url": "_framework/Microsoft.Extensions.Configuration.jqj4k4pj3p.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-UEyHGvSMJcogGcPp3nJ44dBThk3Meup62qjxBK1Grkc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.oqx6sct5lh.wasm"
    },
    {
      "hash": "sha256-npldTut68mqzQngvA3K/GSRCbYWhEVEjs1SJ18ArUuo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.isypqwhob8.wasm"
    },
    {
      "hash": "sha256-nAW02+CSARAMBc7dCGw3tEdPcY2Ea7LRoJZ+pQg8HNs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.w3dl0sqxt4.wasm"
    },
    {
      "hash": "sha256-z4Ak8vQJcnIfzlVFZnyAJM4B7WHbWY+y0BTjBNpGCIg=",
      "url": "_framework/Microsoft.Extensions.Http.f8y2f23mum.wasm"
    },
    {
      "hash": "sha256-BbUBwNjG8MV2/myv1NTXmYsz4Yx635wJApJ+9JkLbRc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.1166p2d2r3.wasm"
    },
    {
      "hash": "sha256-KxQRALLWphBZ94pd3qlD4g6jQNF7HqBhI8tD42J4KuU=",
      "url": "_framework/Microsoft.Extensions.Logging.b80wvzqf2v.wasm"
    },
    {
      "hash": "sha256-pyWsUcPd3YLorRQE70Uke2ADx3z5FztEUqfU+lnWTo4=",
      "url": "_framework/Microsoft.Extensions.Options.9w9x65j0r5.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-3m9+N0AwJN6mNM+APJSSlplSEaUtqg8mn7fVPAKVonY=",
      "url": "_framework/Microsoft.JSInterop.mfbx0ypmiz.wasm"
    },
    {
      "hash": "sha256-Yp6F/C5xFSS+Z/idJ/8YQ6kM/46JHssrXe3uWkdrPxA=",
      "url": "_framework/Microsoft.Win32.Primitives.at4tofna6k.wasm"
    },
    {
      "hash": "sha256-KrBZoSnCsRQAqrwu1iPQ4Cm0ug/tRIziv1fgew5WBp4=",
      "url": "_framework/Microsoft.Win32.SystemEvents.657o6g3htu.wasm"
    },
    {
      "hash": "sha256-QDnNy/ugr6b4YeyF+FuAd0LpvF3aoxNGX+s4gMXwnSU=",
      "url": "_framework/SkiaSharp.HarfBuzz.wo40foal5z.wasm"
    },
    {
      "hash": "sha256-E1G6pci6mPDqE6x1NmMVlOmK04ffi8FH46c4lk37SbQ=",
      "url": "_framework/SkiaSharp.hrd5acinfr.wasm"
    },
    {
      "hash": "sha256-PqE6xZcxt2mCu/8+mcd0y4XBk6RChD6Ucm5kdVLX0lc=",
      "url": "_framework/System.Collections.Concurrent.ud9112pojl.wasm"
    },
    {
      "hash": "sha256-2ieTO6TEqILDhzWtK3BcrUfUuSS28kyi7O995e0n+l4=",
      "url": "_framework/System.Collections.Immutable.2ddi0x2yyn.wasm"
    },
    {
      "hash": "sha256-cwMee4kDXI5NgQBD+f77poIbUiDQPIfTAdhOSwcl0Nk=",
      "url": "_framework/System.Collections.NonGeneric.nb5i84wecp.wasm"
    },
    {
      "hash": "sha256-CKoDCU5KTzdFbWGNrQGN83hgPM7OIIQezSoRBQroY14=",
      "url": "_framework/System.Collections.Specialized.8ctqbmdvny.wasm"
    },
    {
      "hash": "sha256-iiGYdWwEeHfB+rKC8t6N6/4ewURFpDUXbicOY9vO/88=",
      "url": "_framework/System.Collections.m41ndbk8qz.wasm"
    },
    {
      "hash": "sha256-R0ihPOWDdlHaSlg4xL270l3c0LZVQTku4XwD6hCZE9k=",
      "url": "_framework/System.ComponentModel.9gjlqmj7ha.wasm"
    },
    {
      "hash": "sha256-TwOza2Q9TVBwBSN1rfYdl14sDcvP0JMOrnVSyha/4zY=",
      "url": "_framework/System.ComponentModel.Annotations.3ntppurow9.wasm"
    },
    {
      "hash": "sha256-gGd7f2aITUhxjNJhm4muv8Qpxo/46bdI1gA2YUS9GAw=",
      "url": "_framework/System.ComponentModel.Primitives.cx91vk3oo0.wasm"
    },
    {
      "hash": "sha256-d8xJVqOxdb9zS0XmpvkLvk7eDzplTJsYNSyemaepNTI=",
      "url": "_framework/System.ComponentModel.TypeConverter.feb34v9qh7.wasm"
    },
    {
      "hash": "sha256-AOz2engWlbmDEWm7mcz/baGvz9nW2v2lo1th99ncuMI=",
      "url": "_framework/System.Console.k7vochnqe5.wasm"
    },
    {
      "hash": "sha256-PHbuqOz6UW70EkVxhFM2rRNNPtDLYAYh9kfjC1CgM84=",
      "url": "_framework/System.Data.Common.kwrupasf9f.wasm"
    },
    {
      "hash": "sha256-hFa3pwff0qtUNFWZOxdfmquK7JdcYv4blqVpeL0wSe4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.01uuzc3uo4.wasm"
    },
    {
      "hash": "sha256-0DOmj4SePcbVs2Y0zWHXVF/1+MgI/1AWXfWxJmr9GvI=",
      "url": "_framework/System.Diagnostics.Process.c53tfq4rvp.wasm"
    },
    {
      "hash": "sha256-uWP/UaYyp/MTWqwc7NP76DKvA8n7ucS/9XU090RQRnE=",
      "url": "_framework/System.Diagnostics.TraceSource.hie92kyycg.wasm"
    },
    {
      "hash": "sha256-+P6iv9BqBaSzIMcl/QoNjmkXV39NyvncqPXZ1Ss7398=",
      "url": "_framework/System.Drawing.8wgi7x9zvd.wasm"
    },
    {
      "hash": "sha256-Ue28hX+sb37f7G/zpf9wgQ00XLl9BVcvNWoeRd75td4=",
      "url": "_framework/System.Drawing.Common.76lm6qltfz.wasm"
    },
    {
      "hash": "sha256-/d8vJZoXT3zqWJhibj3L+tPV5+ZnyA4UgELTXl/wq6U=",
      "url": "_framework/System.Drawing.Primitives.rq8fi5wvfm.wasm"
    },
    {
      "hash": "sha256-UkCWbUxR1feOgAFKm6c+5l44anlZjJUaRW/47396K/w=",
      "url": "_framework/System.IO.Compression.a5r1gka8lz.wasm"
    },
    {
      "hash": "sha256-mYIjH5GvxCipncRjS6PwCixrtlPFY6PS78bbZOGhDCI=",
      "url": "_framework/System.IO.Packaging.jp1jyfvw1f.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-gjQMO/9rcloCYFJOQ0ZRiKZyVuRwnarTKzAQuOBzNh0=",
      "url": "_framework/System.Linq.2sllnzf4wc.wasm"
    },
    {
      "hash": "sha256-EHIJ6sboZDvRghju+5cfd4kRP/nMo70r1+AMIr+2awc=",
      "url": "_framework/System.Linq.Expressions.c5nz2fhdpq.wasm"
    },
    {
      "hash": "sha256-WPNo+uzZTZsFnIYXX4qAiQDkV5uoU5cT3FYIhUfh48w=",
      "url": "_framework/System.Memory.4ppxvduxmr.wasm"
    },
    {
      "hash": "sha256-f1WAeERjyeSd/ZXh2mTj8yS5s5nBkvPgGVmRs7ia1CA=",
      "url": "_framework/System.Net.Http.l7bjv30ivi.wasm"
    },
    {
      "hash": "sha256-qF2YG3kEzQSeC/d0Oq4qklv/+AIZCTKKX3cv8l/c7X4=",
      "url": "_framework/System.Net.Primitives.wyzlxiv7kk.wasm"
    },
    {
      "hash": "sha256-L2OBlNjxPiNVmUbtvWIgSsM6CwnA01MpLRzee8+SjAc=",
      "url": "_framework/System.Net.Requests.rlul1pnrnr.wasm"
    },
    {
      "hash": "sha256-qvDS0d635T+jWS7NjfrNRXZ/xl8yL9Nr7H866Hn31BA=",
      "url": "_framework/System.Net.WebClient.y1ho3wcqzw.wasm"
    },
    {
      "hash": "sha256-WJ0GmhVGA3g4HkvKCr8BPyrZoAI3G8jjdbtkRMTVzPc=",
      "url": "_framework/System.Net.WebProxy.cjy2amqim3.wasm"
    },
    {
      "hash": "sha256-38HN1ZugBbOfqqw1A/W7qE5mFR5jwuBSFvELSA1Cpow=",
      "url": "_framework/System.Numerics.Vectors.lnt8u6ob9j.wasm"
    },
    {
      "hash": "sha256-gKG8Srjp/lM4SiGkKRqmLi/2LPI3+9d606ObPQ8qGfk=",
      "url": "_framework/System.ObjectModel.8i7mamj599.wasm"
    },
    {
      "hash": "sha256-NgmIpqyBLcqY+oMfbIR28gke3HUEtGROlKXCP48JSW4=",
      "url": "_framework/System.Private.CoreLib.aw8vsfk19w.wasm"
    },
    {
      "hash": "sha256-OYxfluMPn6LnalbKy7uQO+IZpiGq7UgKSzQJ9DXRDj8=",
      "url": "_framework/System.Private.Uri.jlwft1c6lp.wasm"
    },
    {
      "hash": "sha256-fFbODsVtXJUQfD17Gm00AiL/oX8hB6th38FTQU8zk70=",
      "url": "_framework/System.Private.Windows.Core.0jp9xrm0bx.wasm"
    },
    {
      "hash": "sha256-RoBldCIhzx0xMjrksQDTaPr6P+uANa+ybydO3Crc2ko=",
      "url": "_framework/System.Private.Windows.GdiPlus.qf5bg4ny6l.wasm"
    },
    {
      "hash": "sha256-zFyu58m/9LpK7cp2Gs1ac2/A6www65USpr4B9C9TXwA=",
      "url": "_framework/System.Private.Xml.gnw66z8zwg.wasm"
    },
    {
      "hash": "sha256-+lTW6T+oB7Ve4CzWI/kh4+2QAbmujxmGktpKvkWuRqw=",
      "url": "_framework/System.Reflection.Metadata.mdh0twceug.wasm"
    },
    {
      "hash": "sha256-92R3nRJPQsjz63+VUnSLxSnP6Unt70BWlwZWTXTbozk=",
      "url": "_framework/System.Runtime.59o1ii1e09.wasm"
    },
    {
      "hash": "sha256-YPTbJqTzQecArW14f+cqjzje6G3WTPNYgjXCUKUmatY=",
      "url": "_framework/System.Runtime.InteropServices.4voi2x874r.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-x/v5BWhS2ujcUimVv5gZ/lZhoMyoTqzE26Ttvyh/ocQ=",
      "url": "_framework/System.Runtime.Numerics.p80kuaow3u.wasm"
    },
    {
      "hash": "sha256-VO1MhAdgZ28CZKg3RCpUunMROlTicP6KXwMDyOn+a4c=",
      "url": "_framework/System.Runtime.Serialization.Formatters.wxxuuygxxd.wasm"
    },
    {
      "hash": "sha256-diRXhyEABiD+vfnmAWGj0MrJ9Mvq2g18jgfd/wmuDFU=",
      "url": "_framework/System.Security.AccessControl.22cezhc86n.wasm"
    },
    {
      "hash": "sha256-jAO52ocmhbdPdoEfYbO5FM8vz9uuId/q+AKPB/6uU4w=",
      "url": "_framework/System.Security.Cryptography.swr1ctak8p.wasm"
    },
    {
      "hash": "sha256-2fIoEcpAy9Xl82kv9SOomdYpr9pB3adhMkwq3/3wWA8=",
      "url": "_framework/System.Security.Principal.Windows.nca713pj9y.wasm"
    },
    {
      "hash": "sha256-XVXaXj7jrYRcWUfuFPiZb1lZ+FKrrUaKSdSEw/1adLE=",
      "url": "_framework/System.Text.Encoding.Extensions.xfe1y1hxlr.wasm"
    },
    {
      "hash": "sha256-pq7ydT00u5UQm/avQFu31YBwr+Si5LyFKIzcQHmlJu8=",
      "url": "_framework/System.Text.Encodings.Web.i13tyue6z7.wasm"
    },
    {
      "hash": "sha256-DbZRkQ/CVkqVCAOPPkzAF+j+KZJhp39L+tv0rj22V6Q=",
      "url": "_framework/System.Text.Json.7vpolbns0l.wasm"
    },
    {
      "hash": "sha256-4TCNL1/q3QaYR6+yeLoRuLABdEPgDJ5aMq3bPETIyC0=",
      "url": "_framework/System.Text.RegularExpressions.bl6v46wtv6.wasm"
    },
    {
      "hash": "sha256-E1d95qsNnC5C5JYCako8RdisRCGJ/7J/qwtVTi61oTM=",
      "url": "_framework/System.Threading.7n99uc38rb.wasm"
    },
    {
      "hash": "sha256-8Pmec1g8EYm2LuMICrusB7FmW2eB/rVCqTLEvAl22UA=",
      "url": "_framework/System.Threading.Thread.0k4sc5serf.wasm"
    },
    {
      "hash": "sha256-4Y2T9XzyVKssIj3Oy4gCVtp2SIgcjYnFnFWX0wYXqqo=",
      "url": "_framework/System.Xml.ReaderWriter.1k57eubnju.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-geCgGkEQiIdxKNLajwjmNOhsXCbp7+0hNFwulDU+FWI=",
      "url": "_framework/Toolbelt.Blazor.FileDropZone.5vai5xhiw5.wasm"
    },
    {
      "hash": "sha256-uEqZyi2NEDHWcMSlIbQow1hI/lrtGvD06lrLdy6zrRA=",
      "url": "_framework/Toolbelt.Blazor.I18nText.ogbh9ibufd.wasm"
    },
    {
      "hash": "sha256-d7AW3nN8MLS68WwdTO6gWfGlTHoncLYQlsdnhk8BaSI=",
      "url": "_framework/Topten.RichTextKit.ldyuaf2170.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-x3z7vLcSMfZWjR/v5P5AkpXx5eBhpbxdHmSPBQu0+vk=",
      "url": "_framework/de/IgniteUI.Blazor.Documents.Core.resources.3lxbybhyel.wasm"
    },
    {
      "hash": "sha256-wCIg51vzZ4PvSqDmZR48QTTh+6lN5QI+nJ8rcOYIwLY=",
      "url": "_framework/de/IgniteUI.Blazor.Documents.Excel.resources.sdl48k4ius.wasm"
    },
    {
      "hash": "sha256-X2GnTDscw3tGdJDYAXkMdmXdRrokxF7Wlm4vZYKPRx0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-sRflRQP2q5wFSBxLjPzxWR3hZkSgwQYHo1hMbNNHBWA=",
      "url": "_framework/dotnet.native.5z0js4azyp.js"
    },
    {
      "hash": "sha256-BI6B1LfosBq/2Q0ODtyLue40Beb5swhq9bgeadsf9wU=",
      "url": "_framework/dotnet.native.kqw90h4hca.wasm"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-3OcgQ3gphPFsLWjlXB0sRJiWkiKWVb9piTygOi3arrM=",
      "url": "_framework/es/IgniteUI.Blazor.Documents.Core.resources.4i5oqr1cs0.wasm"
    },
    {
      "hash": "sha256-4t+ZZekJaWfVWL35AzDJWqPNNgz4BWTVDbEeHlN1B5g=",
      "url": "_framework/es/IgniteUI.Blazor.Documents.Excel.resources.ifj3zixoso.wasm"
    },
    {
      "hash": "sha256-JNLDq7UKsOCWwFkdou/zkv6948u7fO4v4g5/7ocA/sc=",
      "url": "_framework/fr/IgniteUI.Blazor.Documents.Core.resources.sg450y4qc1.wasm"
    },
    {
      "hash": "sha256-HRulVCkUhKgz7qsiLBzhxd25MvAeLdV2CNBQfGdd1tI=",
      "url": "_framework/fr/IgniteUI.Blazor.Documents.Excel.resources.xrzsb3yiu2.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-1zSVKC7bbPGh/T/n/hiJ3N7ALxXd2BDQ+wSfY5WV9TQ=",
      "url": "_framework/ja/IgniteUI.Blazor.Documents.Core.resources.xaiqcczylv.wasm"
    },
    {
      "hash": "sha256-3stcAM2MsicB8T8wJMsO7qKml+enYn/ZsjNpb7fotCk=",
      "url": "_framework/ja/IgniteUI.Blazor.Documents.Excel.resources.uw8zofgwor.wasm"
    },
    {
      "hash": "sha256-QgeilgG730ch5vNFgh81WA+AIJD2D4AySMaA5/YsFpw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-qSa9utJYGKjRCFUXFYv+stCTWCuE7uOD1+NynJ42V9I=",
      "url": "css/loading.css"
    },
    {
      "hash": "sha256-KtV5C8NHBdt7K0zNbUEprfSASfvv5TJ1VZc1nSvwtnI=",
      "url": "dockmanager-helper.js"
    },
    {
      "hash": "sha256-5isFuaZXnWKj6DHD82TZtt54KttxwZPeucyXf1ySerU=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-qBRKW3pcAlXzxMDHuqZdZA0p4mfqA3ua9N2eOdkc31s=",
      "url": "ig-logo.svg"
    },
    {
      "hash": "sha256-Wzt8vxqNqy9mryZAA04UCwQtMC96zsjqF/kIStSr0i8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-So0on1DDpEYOfJnPsk+oD0suy/2a3tOPYABtbfijgkE=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-B7DyD9j3EoTUrN+XJYKORw3SjNJCXRMGo+lB+QHB4zA=",
      "url": "sample-data-en.xlsx"
    },
    {
      "hash": "sha256-GoZXER5aH0E9pG0nVPSpbYeOuYjgECNAnP1NK0iubfs=",
      "url": "sample-data-ja.xlsx"
    },
    {
      "hash": "sha256-Su+lGYHiBxsphT1l2FE0UdPUUrurRgraT6mv1nO8NdE=",
      "url": "sample-data-ko.xlsx"
    }
  ]
};
